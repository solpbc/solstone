solstone-tmux requires tmux.
Install with: install -m 0755 solstone-tmux /usr/local/bin/solstone-tmux
